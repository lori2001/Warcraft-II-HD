A BIG portion of this file has been deleted in order to be able to put it on github.
Search the internet for the full file if you need it.
